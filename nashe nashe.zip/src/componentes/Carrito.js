import React from 'react'
import { Link } from 'react-router-dom'



const Carrito= ({itemsCarrito,agregarCarrito,restarCarrito,limpiarCarrito})=>{
    const precioTotal=itemsCarrito.reduce((precio,item)=>precio + item.cantidad*item.precio,0)
    return(
        <div className='carrito'>
            <div className='cabecera-itemsCarrito'>
            <span>Carrito</span>
                {itemsCarrito.length >=1 && (
                    <button onClick={limpiarCarrito}>Limpiar carrito</button>
                )}
            </div>
            <div className='contenedor-itemCarrito'>
                {itemsCarrito.length === 0 &&(<div>No hay items en el carrito berraco, comprate algo </div>)}
                {
                    itemsCarrito.map((item)=>(
                        
                            <div key={item.id} className='itemCarrito'>
                                <div className='informacion-itemCarrito'>
                                    <img src={item.poster} alt={item.name}/>
                                    <ul>
                                        <li><b>Nombre:</b> {item.nombre}</li>
                                        <li><b>Genero:</b> {item.genero}</li>
                                    </ul>
                                </div>
                                <div className='btn-carrito'>
                                    <button onClick={()=>agregarCarrito(item)}><img src='https://cdn-icons-png.flaticon.com/512/148/148764.png'/></button>
                                    <button onClick={()=>restarCarrito(item)}><img src='https://cdn-icons-png.flaticon.com/512/1828/1828595.png'/></button>
                                    Dias: {item.cantidad} - Precio x/dia ${item.precio}
                                </div>
                            </div>
                        
                    ))
                }
            </div>
            <div className='precioFinal'>
                <h4>Precio total= <span>${precioTotal}</span></h4>
                <Link to='/metodopago'><button onClick={limpiarCarrito}>Finalizar Compra</button></Link>

            </div>
        </div>
    )
}
export default Carrito;