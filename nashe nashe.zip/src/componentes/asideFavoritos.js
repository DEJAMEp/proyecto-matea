import React from 'react'

const AsideFavoritos = ({itemsAside}) => {
    return (
        <aside>
        <img src='https://cuevana3.io/wp-content/themes/cuevana3/public/img/got.png'/>
        <div className='destacados-aside'>
            <h1>Destacados</h1>
            <hr/>
            <div className='contenedor-cartas-aside'>
                {
                    itemsAside.map((item)=>(
                        <>
                            <div key={item.id} className='itemAside'>
                                <img src={item.poster} alt={item.nombre}/>
                                <div className='contenedor-lista-aside'>
                                    <ul>
                                        <li>{item.ranking}</li>
                                        <li>{item.duracion}</li>
                                        <li>{item.año}</li>
                                    </ul>
                                </div><hr/>
                            </div>
                        </>
                    ))
                }
            </div>
        </div>
    </aside>

    )
}

export default AsideFavoritos
