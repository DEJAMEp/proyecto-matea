import { useState } from "react";
import { BrowserRouter as Render,Routes,Route, Link } from "react-router-dom";
import Data from "./componentes/Data/Data";
import Footer from "./componentes/footer/footer";
import Header from "./componentes/Header";
import Rout from "./componentes/Routes";

const App= ()=> {
  const {itemProductos,itemsAside,itemsEstreno,itemsRanking}= Data;
  const [itemsCarrito,setItemsCarrito]= useState([]);
  const [itemsFavorito,setItemsFavorito]=useState([]);

  const agregarCarrito=(producto)=>{
    const ProductoExiste = itemsCarrito.find((item)=>item.id === producto.id);
    if(ProductoExiste){
      setItemsCarrito(itemsCarrito.map(
          (item)=> item.id === producto.id ? 
            {...ProductoExiste, cantidad: ProductoExiste.cantidad +1}
          :item 
          ))
    }else{
      setItemsCarrito([...itemsCarrito,{...producto,cantidad: 1}])
    }
  }
  const restarCarrito=(producto)=>{
    const ProductoExiste = itemsCarrito.find((item)=>item.id === producto.id);
    if(ProductoExiste.cantidad === 1){
      setItemsCarrito(
        itemsCarrito.filter((item)=>item.id!==producto.id)
        )
  }else{
    setItemsCarrito(
      itemsCarrito.map((item)=>item.id===producto.id?{...ProductoExiste, cantidad: ProductoExiste.cantidad -1}:item)
      )
  }
  }
  const limpiarCarrito= ()=>{
    setItemsCarrito([])
  }

  const agregarFavorito=(producto)=>{
    const Existe = itemsFavorito.find((item)=>item.id === producto.id);
    if(Existe){
      setItemsFavorito(itemsFavorito.map(
          (item)=> item.id === producto.id ? 
            {...Existe, cantidad: Existe.cantidad +1}
          :item 
          ))
    }else{
      setItemsFavorito([...itemsFavorito,{...producto,cantidad: 1}])
    }
  }
  const limpiarFavorito= ()=>{
    setItemsFavorito([])
  }

  const restarFavorito=(producto)=>{
    const Existe = itemsFavorito.find((item)=>item.id === producto.id);
    if(Existe.cantidad === 1){
      setItemsFavorito(
        itemsFavorito.filter((item)=>item.id!==producto.id)
        )
  }else{
    setItemsFavorito(
      itemsFavorito.map((item)=>item.id===producto.id?{...Existe, cantidad: Existe.cantidad -1}:item)
      )
  }
  }





  return(
    <Render>
      <Header itemsCarrito={itemsCarrito} itemsFavorito={itemsFavorito}/>
      <Rout itemProductos={itemProductos} itemsCarrito={itemsCarrito} agregarCarrito={agregarCarrito} restarCarrito={restarCarrito} limpiarCarrito={limpiarCarrito}itemsFavorito={itemsFavorito}agregarFavorito={agregarFavorito} limpiarFavorito={limpiarFavorito} restarFavorito={restarFavorito} itemsEstreno={itemsEstreno} itemsRanking={itemsRanking} itemsAside={itemsAside}/>
      <Footer/>
    </Render>
  )
}
export default App;